/* script.js - Interações do site PET'S */
/* Comentários descrevem cada seção para fácil manutenção */

/* DOM helpers */
const qs = (s, root=document) => root.querySelector(s);
const qsa = (s, root=document) => Array.from(root.querySelectorAll(s));

/* Update copyright years */
document.addEventListener('DOMContentLoaded', () => {
  const year = new Date().getFullYear();
  const y = qs('#year'); if(y) y.textContent = year;
  const yc = qs('#year-caes'); if(yc) yc.textContent = year;
  const yg = qs('#year-gatos'); if(yg) yg.textContent = year;

  initHamburger();
  initCards();
  initModalClose();
});

/* Hamburger menu for mobile */
function initHamburger(){
  const btn = qs('#hamburger');
  const nav = qs('.nav');
  if(!btn || !nav) return;
  btn.addEventListener('click', () => {
    const expanded = btn.getAttribute('aria-expanded') === 'true';
    btn.setAttribute('aria-expanded', String(!expanded));
    nav.classList.toggle('open');
  });

  // Close nav when clicking outside on mobile
  document.addEventListener('click', (e) => {
    if(!nav.classList.contains('open')) return;
    if(e.target.closest('.nav') || e.target.closest('.hamburger')) return;
    nav.classList.remove('open');
    btn.setAttribute('aria-expanded','false');
  });
}

/* Card interactions: abrir modal com imagem maior e descrição */
function initCards(){
  const cards = qsa('.card');
  if(!cards.length) return;
  cards.forEach(card => {
    const open = () => {
      const title = card.dataset.title || qs('.card-title', card)?.textContent || '';
      const desc = card.dataset.desc || qs('.card-text', card)?.textContent || '';
      const img = card.dataset.img || qs('.card-media img', card)?.src || '';

      openModal({title, desc, img});
    };
    card.addEventListener('click', open);
    card.addEventListener('keypress', (e) => { if(e.key === 'Enter') open(); });
  });
}

/* Modal behavior */
const modal = qs('#modal');
const modalImg = qs('#modal-img');
const modalTitle = qs('#modal-title');
const modalDesc = qs('#modal-desc');
const modalCloseBtn = qs('#modal-close');

function openModal({title='', desc='', img=''}) {
  if(!modal) return;
  modalImg.src = img;
  modalImg.alt = title;
  modalTitle.textContent = title;
  modalDesc.textContent = desc;
  modal.setAttribute('aria-hidden','false');
  document.body.style.overflow = 'hidden';
  // focus trap simplified
  modalCloseBtn?.focus();
}

function closeModal(){
  if(!modal) return;
  modal.setAttribute('aria-hidden','true');
  document.body.style.overflow = '';
  modalImg.src = '';
}

/* Close modal events */
function initModalClose(){
  if(!modal) return;
  modal.addEventListener('click', (e) => {
    if(e.target === modal) closeModal();
  });
  if(modalCloseBtn) modalCloseBtn.addEventListener('click', closeModal);
  document.addEventListener('keydown', (e) => {
    if(e.key === 'Escape') closeModal();
  });
}

/* Small enhancement: highlight active nav link based on filename */
(function highlightActiveNav(){
  const links = qsa('.nav-link');
  const path = location.pathname.split('/').pop();
  links.forEach(a => {
    const href = a.getAttribute('href') || '';
    if(href === path) {
      a.classList.add('active');
    } else {
      // keep existing classes
    }
  });
})();